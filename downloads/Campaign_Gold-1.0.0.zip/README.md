# Campaign Gold

Mod author: **Endek**

Add gold to your bank or set the balance from the campaign map with configurable hotkeys.

Press **F6** to add 100 gold, or **F7** to set the balance to 999. Both keys and amounts are configurable in `BepInEx/config/local.badnorth.campaign-gold.cfg` after first launch. Changes on the campaign map are saved to the active campaign.

在战役地图上按 F6 增加金币，按 F7 设置余额。按键和数值可配置。

## Installation

Install through Thunderstore Mod Manager or r2modman and start Bad North with the selected profile. The Bad North BepInEx pack is listed as a dependency.

For a manual install, set up BepInEx 5 x86 first. Copy the files from `plugins/CampaignGold` into `BepInEx/plugins/CampaignGold` inside your game folder.

[Source code](https://github.com/Endek93/BadNorth_modding/tree/main/ModDevelopment/Mods/CampaignGold) · [Report an issue](https://github.com/Endek93/BadNorth_modding/issues)
