# Save Compatibility

Prunes unavailable upgrades from the player profile after you remove mods that added them.

**Back up your player profile before using this mod.** It removes unavailable entries from saved collection and starting loadout data, then writes the updated profile. Use it when an upgrade in your profile comes from a mod you no longer have installed.

用于清理卸载 Mod 后留在玩家档案里的无效升级条目。插件会重写档案，使用前请备份。

## Installation

Install through Thunderstore Mod Manager or r2modman and start Bad North with the selected profile. The Bad North BepInEx pack is listed as a dependency.

For a manual install, set up BepInEx 5 x86 first. Copy the files from `plugins/SaveCompatibility` into `BepInEx/plugins/SaveCompatibility` inside your game folder.

[Source code](https://github.com/Endek93/BadNorth_modding/tree/main/ModDevelopment/Mods/SaveCompatibility) · [Report an issue](https://github.com/Endek93/BadNorth_modding/issues)
