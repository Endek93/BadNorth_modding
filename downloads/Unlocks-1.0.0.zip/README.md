# Unlocks

Unlocks the collection and lets you choose traits, items and consumables when starting a campaign.

The collection shows available upgrades at their highest unlocked level. When starting a campaign, the loadout selector offers all available traits, items and consumables.

解锁收藏中的升级，并在新战役的初始配置里开放特质、道具和消耗品。

## Installation

Install through Thunderstore Mod Manager or r2modman and start Bad North with the selected profile. The Bad North BepInEx pack is listed as a dependency.

For a manual install, set up BepInEx 5 x86 first. Copy the files from `plugins/Unlocks` into `BepInEx/plugins/Unlocks` inside your game folder.

[Source code](https://github.com/Endek93/BadNorth_modding/tree/main/ModDevelopment/Mods/Unlocks) · [Report an issue](https://github.com/Endek93/BadNorth_modding/issues)
