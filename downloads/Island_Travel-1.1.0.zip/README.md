# Island Travel

Open campaign islands for travel and optionally keep the Viking frontier in place between turns.

Travel to islands beyond the normal campaign limits. `FreezeFrontier` defaults to `true`. Set it to `false` in `BepInEx/config/local.badnorth.island-travel.cfg` to let the frontier advance between turns.

解除战役地图的岛屿出行限制。可以通过配置决定维京推进线是否随回合前进。

## Installation

Install through Thunderstore Mod Manager or r2modman and start Bad North with the selected profile. The Bad North BepInEx pack is listed as a dependency.

For a manual install, set up BepInEx 5 x86 first. Copy the files from `plugins/IslandTravel` into `BepInEx/plugins/IslandTravel` inside your game folder.

[Source code](https://github.com/Endek93/BadNorth_modding/tree/main/ModDevelopment/Mods/IslandTravel) · [Report an issue](https://github.com/Endek93/BadNorth_modding/issues)
