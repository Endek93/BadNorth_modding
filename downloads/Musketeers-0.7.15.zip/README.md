# Musketeers

Mod author: **Endek**

Adds Musketeers as an alternative to the final Archer upgrade, with custom equipment, gunfire and combat effects.

When an Archer squad is one tier below its final upgrade, choose Musketeers from the campaign upgrade menu. The squad converts to a musket unit with custom uniforms, reload animations, and firing effects.

在弓箭手升到最后一阶时，可以在战役升级界面选择火枪手分支。

## 0.7.15

Musketeers shoulder their muskets when idle, with the barrel tilted slightly back and the trigger guard turned inward. The updated model has a brass butt plate and an open trigger guard. The muzzle and shot effects follow the new barrel length.

## 0.7.10

Musketeers across squads spread their fire. At most two Musketeers can attack the same enemy at once, counting active aim and bullets in flight.

## Audio credit

The musket sound is adapted from [musket_fire_9.wav by J8054](https://freesound.org/people/J8054/sounds/648755/) under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The sound was trimmed, level-adjusted, converted to mono 24 kHz PCM, and mixed with a short impact and filtered reflections. The ZIP includes the full credit notice.

## Installation

Install through Thunderstore Mod Manager or r2modman and start Bad North with the selected profile. The Bad North BepInEx pack is listed as a dependency.

For a manual install, set up BepInEx 5 x86 first. Copy the files from `plugins/Musketeers` into `BepInEx/plugins/Musketeers` inside your game folder.

[Source code](https://github.com/Endek93/BadNorth_modding/tree/main/ModDevelopment/Mods/Musketeers) · [Report an issue](https://github.com/Endek93/BadNorth_modding/issues)
